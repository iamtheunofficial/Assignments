package com.wipro.Assignment5.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.Assignment5.model.Emp;
import com.wipro.Assignment5.service.EmpService;

@RestController
public class EmployeeController {
	
	@Autowired
	EmpService empser;
	
	@GetMapping
	public ResponseEntity<Object> get(){
		return new ResponseEntity<Object>(HttpStatus.NO_CONTENT);
	}
	
	@PostMapping("/addemp")
	public String add(Emp emp)
	{
		String s=empser.addEmp(emp);
		return s;
	}
	
	@PutMapping("/updateemp")
	public String update(Emp emp)
	{
		String s = empser.update(emp);
		return s;
	}
	
	@GetMapping("/display")
	public Map<Integer,Emp> display()
	{
		Map<Integer,Emp>  list =  empser.display();
		return list;
	}
	
	@DeleteMapping("/delete")
	public String delete(Emp emp)
	{
		String s = empser.delete(emp);
		return s;
	}
}
