package com.wipro.Assignment5.service;


import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.wipro.Assignment5.model.Emp;


@Service
public class EmpService
{
	Map<Integer,Emp> list=new HashMap<>();
	
	public String addEmp(Emp emp) {
		list.put(emp.getEmpId(),emp);
		System.out.println(list);
		return "employee added successfully" ;
	}
	
	public String update(Emp emp) {
		
		if(list.containsKey(emp.getEmpId())) {
			list.put(emp.getEmpId(),emp);
			System.out.println(list);
			return "updated successfully";
		}
		return "no employee id";
	}
	
	public Map<Integer,Emp> display()
	{
			return list;
	}
	
	public String delete(Emp emp)
	{
		list.remove(emp.getEmpId());
		System.out.println(list);
		return "Deleted employee";
				
	}
	
	
}
