package com.wipro.Assignment1;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

		@RequestMapping("/bankName")
		public String bank()
		{
			return "HDFC Bank";
		}
		
		@RequestMapping("/bankAddress")
		public String address()
		{
			return "Banglore";
		}
}
