package com.wipro.Assignment4.model;

import jakarta.persistence.*;

@Entity
public class Employee {
	
	@Id
	private int empId;
	private String empName;
	private String email;
	private String location;
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int empId, String empName, String email, String location) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.email = email;
		this.location = location;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", email=" + email + ", Location=" + location
				+ "]";
	}
	
	
}
