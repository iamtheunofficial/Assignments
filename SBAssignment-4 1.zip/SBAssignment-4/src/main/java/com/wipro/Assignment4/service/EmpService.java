package com.wipro.Assignment4.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.Assignment4.model.Employee;
import com.wipro.Assignment4.repository.EmpRepo;

@Service
public class EmpService 
{
	@Autowired
	EmpRepo emprepo;
	
	
	public void save(Employee emp)
	{
		emprepo.save(emp);
	}
	
	public List<Employee> findall()
	{
		return emprepo.findAll();
	}
	
	public Employee findbyid(int emp)
	{
		return emprepo.findByempId(emp);
	}
}
