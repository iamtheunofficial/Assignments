package com.wipro.Assignment4.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.wipro.Assignment4.model.Employee;
import com.wipro.Assignment4.service.EmpService;

@Controller
public class EmpController 
{
	
	@Autowired
	EmpService empserv;
	
	@RequestMapping("/insert")
	public String add()
	{
		return "index";
	}
	
	@PostMapping("/insert1")
	public String add1(@ModelAttribute Employee emp, Model m)
	{
		System.out.println("came here");
		empserv.save(emp);
		String msg = "Inseted Seuccefully";
		m.addAttribute("msg",msg);
		return "index";
	}
	
	@RequestMapping("/displayall")
	public String display(Model m)
	{
		List<Employee> em = empserv.findall();
		m.addAttribute("list",em);
		System.out.println("em"+ em);
		return "display";
	}
	
	@RequestMapping("/findByid")
	public String findbyid()
	{
		
		return "findbyid";
	}
	
	@PostMapping("/searchbyid")
	public String findbyid(@RequestParam int empId,Model m)
	{
		Employee em = empserv.findbyid(empId);
		m.addAttribute("emp",em);
		System.out.println(em);
		return "findbyid";
	}
	
}
