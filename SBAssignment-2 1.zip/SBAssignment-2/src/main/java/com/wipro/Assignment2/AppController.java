package com.wipro.Assignment2;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AppController {
	
	@RequestMapping("/bankName")
	public String bankName()
	{
		return "bankname";
	}
	
	@RequestMapping("bankService")
	public String bankService()
	{
		return "bankservice";
	}
}
